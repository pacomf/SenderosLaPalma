var mongoose = require('mongoose'),
    Schema = mongoose.Schema;

var geoLocScheme = new Schema({
    latitude: Number,
    longitude: Number
});

module.exports = mongoose.model('GeoLoc', geoLocScheme)